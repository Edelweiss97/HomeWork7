package com.company;

public interface HavingSuperAbility {
    void applySuperAbility();
}
