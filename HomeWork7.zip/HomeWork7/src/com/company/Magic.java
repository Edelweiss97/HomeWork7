package com.company;

public class Magic extends Hero {
    @Override
    public void applySuperAbility() {
        System.out.println("Magic применил суперспособность FireBall");
    }
}
